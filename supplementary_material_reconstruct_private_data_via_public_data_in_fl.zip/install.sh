pip install pybind11
pip install -U git+https://github.com/Koukyosyumei/AIJack
pip install -e .